from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from db_manager import DatabaseManager


# start_app fonksiyonu parametre olarak alınıyor.

class DashboardUI:
    """Personel ve Admin kullanıcıları için Ana Yönetim Paneli."""

    def __init__(self, master, yetki, logout_command):
        self.master = master
        self.yetki = yetki
        self.logout_command = logout_command

        master.title(f"Eczane Otomasyon Sistemi | {self.yetki.upper()} Paneli")
        master.geometry("1200x700")

        master.grid_rowconfigure(0, weight=1)
        master.grid_columnconfigure(1, weight=1)

        self.db = DatabaseManager()

        self.create_side_menu()
        self.create_content_area()
        self.show_home_screen()

        # --- YAN MENÜ OLUŞTURMA (GRID) ---

    def create_side_menu(self):
        self.menu_frame = Frame(self.master, bg="#2c3e50", width=200)
        self.menu_frame.grid(row=0, column=0, sticky="nsew")

        self.menu_frame.grid_columnconfigure(0, weight=1)

        Label(self.menu_frame, text="YÖNETİM", bg="#34495e", fg="white",
              font=("Arial", 16, "bold"), pady=15).grid(row=0, column=0, sticky="ew")

        menu_items = [
            ("Anasayfa", self.show_home_screen),
            ("Stok Yönetimi", self.show_stock_management),
            ("Reçete Takibi", self.show_prescription_tracking),
        ]

        if self.yetki == 'yonetici':
            menu_items.append(("Kullanıcı Yönetimi", self.show_user_management))

        row_num = 1
        for text, command in menu_items:
            btn = Button(self.menu_frame, text=text, command=command,
                         bg="#2c3e50", fg="white", font=("Arial", 12),
                         activebackground="#34495e", activeforeground="#2ecc71",
                         relief=FLAT, pady=10)
            btn.grid(row=row_num, column=0, sticky="ew", padx=10, pady=5)
            row_num += 1

        exit_btn = Button(self.menu_frame, text="Çıkış Yap",
                          command=self.handle_logout,
                          bg="#e74c3c", fg="white", font=("Arial", 12, "bold"),
                          relief=FLAT, pady=10)

        self.menu_frame.grid_rowconfigure(row_num, weight=1)
        exit_btn.grid(row=row_num + 1, column=0, sticky="s", padx=10, pady=20)

    def handle_logout(self):
        self.master.destroy()
        self.logout_command()

        # --- ÇALIŞMA ALANI OLUŞTURMA (GRID) ---

    def create_content_area(self):
        self.content_frame = Frame(self.master, bg="#ecf0f1")
        self.content_frame.grid(row=0, column=1, sticky="nsew")

        self.content_frame.grid_columnconfigure(0, weight=1)
        self.content_frame.grid_rowconfigure(1, weight=1)

        self.header_frame = Frame(self.content_frame, bg="#ffffff", height=50, bd=1, relief=RAISED)
        self.header_frame.grid(row=0, column=0, sticky="ew")
        self.header_frame.grid_columnconfigure(1, weight=1)

        Label(self.header_frame, text="Ana Panel", font=("Arial", 16, "bold"), bg="#ffffff", padx=20).grid(row=0,
                                                                                                           column=0,
                                                                                                           sticky="w",
                                                                                                           pady=10)

        user_info = Label(self.header_frame, text=f"Yetki: {self.yetki.upper()}", font=("Arial", 10), bg="#ffffff",
                          fg="#3498db")
        user_info.grid(row=0, column=2, sticky="e", padx=20)

        self.page_container = Frame(self.content_frame, bg="#ecf0f1")
        self.page_container.grid(row=1, column=0, sticky="nsew", padx=20, pady=20)
        self.page_container.grid_columnconfigure(0, weight=1)
        self.page_container.grid_rowconfigure(0, weight=1)

    def clear_content_area(self):
        for widget in self.page_container.winfo_children():
            widget.destroy()

    def show_home_screen(self):
        self.clear_content_area()

        # 1. İstatistikleri DB'den çek
        stats = self.db.get_dashboard_stats()

        # Ana Başlık
        Label(self.page_container, text="📊 ECZANE GÜNCEL DURUM ÖZETİ",
              font=("Arial", 20, "bold"), bg="#ecf0f1", fg="#2c3e50").grid(row=0, column=0, columnspan=4, pady=(0, 30),
                                                                           sticky="w")

        # Grid ayarı: 4 sütunu da eşit genişlikte yap
        self.page_container.grid_columnconfigure(0, weight=1)
        self.page_container.grid_columnconfigure(1, weight=1)
        self.page_container.grid_columnconfigure(2, weight=1)
        self.page_container.grid_columnconfigure(3, weight=1)

        # --- BİLGİ KARTLARI (INFO CARDS) ---

        cards = [
            {
                "title": "Toplam İlaç Çeşidi",
                "value": stats['total_medicines'],
                "icon": "💊",
                "color": "#3498db"  # Mavi
            },
            {
                "title": "Kritik Stok Uyarısı",
                "value": f"{stats['critical_stock_count']} Adet",
                "icon": "🚨",
                # 0'dan büyükse kırmızı, yoksa yeşil
                "color": "#e74c3c" if stats['critical_stock_count'] > 0 else "#2ecc71"
            },
            {
                "title": "Bekleyen Reçete",
                "value": f"{stats['pending_prescriptions']} Adet",
                "icon": "📝",
                "color": "#f39c12"  # Turuncu
            },
            {
                "title": "Kayıtlı Hasta Sayısı",
                "value": stats['total_patients'],
                "icon": "👤",
                "color": "#9b59b6"  # Mor
            }
        ]

        for i, card in enumerate(cards):
            card_frame = Frame(self.page_container, bg=card["color"], padx=20, pady=20, relief=RAISED, bd=1)
            card_frame.grid(row=1, column=i, sticky="nsew", padx=10, pady=10)

            Label(card_frame, text=card["icon"], font=("Arial", 30), bg=card["color"], fg="white").pack(pady=(0, 5))

            Label(card_frame, text=card["title"], font=("Arial", 12), bg=card["color"], fg="white").pack()

            Label(card_frame, text=card["value"], font=("Arial", 24, "bold"), bg=card["color"], fg="white").pack(
                pady=(5, 0))

        # --- ALT KISIM: KULLANICI BİLGİSİ ---
        Label(self.page_container, text=f"\nSisteme Hoş Geldiniz, {self.yetki.upper()} Kullanıcısı.",
              font=("Arial", 14), bg="#ecf0f1").grid(row=2, column=0, columnspan=4, pady=(40, 20), sticky="w")

        Label(self.page_container, text="Menüden ilgili modülü seçerek işleme başlayabilirsiniz.",
              font=("Arial", 12), bg="#ecf0f1", fg="#7f8c8d").grid(row=3, column=0, columnspan=4, sticky="w")

    # =========================================================================
    # 1. STOK YÖNETİMİ MODÜLÜ (CRUD işlemleri dahil)
    # =========================================================================

    def show_stock_management(self):
        self.clear_content_area()

        Label(self.page_container, text="İLAÇ STOK YÖNETİMİ",
              font=("Arial", 18, "bold"), fg="#2c3e50", bg="#ecf0f1").grid(row=0, column=0, columnspan=3, pady=(0, 20),
                                                                           sticky="w")

        self.page_container.grid_columnconfigure(0, weight=0)
        self.page_container.grid_columnconfigure(1, weight=1)
        self.page_container.grid_rowconfigure(1, weight=1)

        self.form_frame = Frame(self.page_container, bg="#ffffff", padx=15, pady=15, relief=GROOVE, bd=1)
        self.form_frame.grid(row=1, column=0, sticky="nsw", padx=(0, 20), pady=10)

        Label(self.form_frame, text="İlaç Kayıt / Güncelleme", font=("Arial", 12, "bold"), bg="#ffffff",
              fg="#3498db").grid(row=0, column=0, columnspan=2, pady=(0, 15))

        fields = [
            ("Barkod No:", "barkod_entry"),
            ("İlaç Adı:", "ad_entry"),
            ("Stok Miktarı:", "stok_entry"),
            ("Fiyat (TL):", "fiyat_entry"),
            ("Son KT (YYYY-MM-DD):", "skt_entry")
        ]

        row_num = 1
        for label_text, entry_attr in fields:
            Label(self.form_frame, text=label_text, bg="#ffffff", font=("Arial", 10)).grid(row=row_num, column=0,
                                                                                           sticky="w", pady=5)
            entry = Entry(self.form_frame, font=("Arial", 10), relief=FLAT, bg="#ecf0f1", width=25)
            entry.grid(row=row_num, column=1, sticky="ew", padx=10, pady=5)
            setattr(self, entry_attr, entry)
            row_num += 1

        Button(self.form_frame, text="İLAÇ EKLE", command=self.add_medicine_ui,
               bg="#2ecc71", fg="white", font=("Arial", 10, "bold"), relief=FLAT).grid(row=row_num, column=0,
                                                                                       pady=(20, 5), padx=5,
                                                                                       sticky="ew")

        Button(self.form_frame, text="GÜNCELLE", command=self.update_medicine_ui,
               bg="#f39c12", fg="white", font=("Arial", 10, "bold"), relief=FLAT).grid(row=row_num, column=1,
                                                                                       pady=(20, 5), padx=5,
                                                                                       sticky="ew")

        row_num += 1
        Button(self.form_frame, text="SEÇİLİ İLACI SİL", command=self.delete_medicine_ui,
               bg="#e74c3c", fg="white", font=("Arial", 10, "bold"), relief=FLAT).grid(row=row_num, column=0,
                                                                                       columnspan=2, pady=5, padx=5,
                                                                                       sticky="ew")

        # --- B. İLAÇ LİSTESİ (SAĞ PANEL - Treeview) ---
        self.list_frame = Frame(self.page_container, bg="#ffffff")
        self.list_frame.grid(row=1, column=1, sticky="nsew", pady=10)
        self.list_frame.grid_rowconfigure(0, weight=1)
        self.list_frame.grid_columnconfigure(0, weight=1)

        scrollbar = Scrollbar(self.list_frame, orient=VERTICAL)

        self.medicine_list = ttk.Treeview(self.list_frame, columns=("ID", "Barkod", "Ad", "Stok", "Fiyat", "SKT"),
                                          show="headings", yscrollcommand=scrollbar.set)

        scrollbar.config(command=self.medicine_list.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')

        self.medicine_list.grid(row=0, column=0, sticky="nsew")

        self.medicine_list.heading("ID", text="ID", anchor=W)
        self.medicine_list.heading("Barkod", text="Barkod No", anchor=W)
        self.medicine_list.heading("Ad", text="İlaç Adı", anchor=W)
        self.medicine_list.heading("Stok", text="Stok", anchor=W)
        self.medicine_list.heading("Fiyat", text="Fiyat (TL)", anchor=W)
        self.medicine_list.heading("SKT", text="Son Kullanma Tarihi", anchor=W)

        self.medicine_list.column("ID", width=30, anchor=CENTER)
        self.medicine_list.column("Barkod", width=100)
        self.medicine_list.column("Ad", width=200)
        self.medicine_list.column("Stok", width=50, anchor=CENTER)
        self.medicine_list.column("Fiyat", width=80, anchor=E)
        self.medicine_list.column("SKT", width=120, anchor=CENTER)

        self.medicine_list.bind("<<TreeviewSelect>>", self.load_medicine_data_to_form)
        self.load_medicine_list()

    def load_medicine_list(self):
        for item in self.medicine_list.get_children():
            self.medicine_list.delete(item)

        medicines = self.db.get_all_medicines()
        for med in medicines:
            self.medicine_list.insert('', END, values=med)

    def load_medicine_data_to_form(self, event):
        selected_item = self.medicine_list.selection()
        if not selected_item: return

        values = self.medicine_list.item(selected_item, 'values')

        for attr in ["barkod_entry", "ad_entry", "stok_entry", "fiyat_entry", "skt_entry"]:
            getattr(self, attr).delete(0, END)

        self.barkod_entry.insert(0, values[1])
        self.ad_entry.insert(0, values[2])
        self.stok_entry.insert(0, values[3])
        self.fiyat_entry.insert(0, values[4])
        self.skt_entry.insert(0, values[5])

    def get_form_data(self):
        barkod = self.barkod_entry.get()
        ad = self.ad_entry.get()
        stok = self.stok_entry.get()
        fiyat = self.fiyat_entry.get()
        skt = self.skt_entry.get()

        if not all([barkod, ad, stok, fiyat, skt]):
            messagebox.showerror("Hata", "Lütfen tüm alanları doldurun.")
            return None

        try:
            stok = int(stok)
            fiyat = float(fiyat)
        except ValueError:
            messagebox.showerror("Hata", "Stok ve Fiyat alanları sayı olmalıdır.")
            return None

        return barkod, ad, stok, fiyat, skt

    def clear_form(self):
        for attr in ["barkod_entry", "ad_entry", "stok_entry", "fiyat_entry", "skt_entry"]:
            getattr(self, attr).delete(0, END)

    def add_medicine_ui(self):
        data = self.get_form_data()
        if not data: return

        barkod, ad, stok, fiyat, skt = data
        success, message = self.db.add_medicine(barkod, ad, stok, fiyat, skt)

        if success:
            messagebox.showinfo("Başarılı", message)
            self.clear_form()
            self.load_medicine_list()
        else:
            messagebox.showerror("Hata", message)

    def update_medicine_ui(self):
        selected_item = self.medicine_list.selection()
        if not selected_item:
            messagebox.showerror("Hata", "Lütfen güncellemek için listeden bir ilaç seçin.")
            return

        med_id = self.medicine_list.item(selected_item, 'values')[0]
        data = self.get_form_data()
        if not data: return

        barkod, ad, stok, fiyat, skt = data
        success, message = self.db.update_medicine(med_id, barkod, ad, stok, fiyat, skt)

        if success:
            messagebox.showinfo("Başarılı", message)
            self.clear_form()
            self.load_medicine_list()
        else:
            messagebox.showerror("Hata", message)

    def delete_medicine_ui(self):
        selected_item = self.medicine_list.selection()
        if not selected_item:
            messagebox.showerror("Hata", "Lütfen silmek için listeden bir ilaç seçin.")
            return

        med_id = self.medicine_list.item(selected_item, 'values')[0]

        if messagebox.askyesno("Onay", f"{med_id} ID'li ilacı silmek istediğinizden emin misiniz?"):
            success, message = self.db.delete_medicine(med_id)
            if success:
                messagebox.showinfo("Başarılı", message)
                self.clear_form()
                self.load_medicine_list()
            else:
                messagebox.showerror("Hata", message)

    # =========================================================================
    # 2. REÇETE TAKİBİ MODÜLÜ (Gelişmiş)
    # =========================================================================
    def show_prescription_tracking(self):
        self.clear_content_area()

        Label(self.page_container, text="REÇETE TAKİP VE YÖNETİMİ",
              font=("Arial", 18, "bold"), fg="#2c3e50", bg="#ecf0f1").grid(row=0, column=0, columnspan=3, pady=(0, 20),
                                                                           sticky="w")

        # --- GRID Ayarları (3 Sütunlu Yapı) ---
        self.page_container.grid_columnconfigure(0, weight=1)  # Hasta Listesi
        self.page_container.grid_columnconfigure(1, weight=0)  # Reçete Formu
        self.page_container.grid_columnconfigure(2, weight=1)  # Tüm Reçeteler Listesi
        self.page_container.grid_rowconfigure(1, weight=1)

        # --- SÜTUN 0: HASTA LİSTESİ ---
        self.patient_list_frame = Frame(self.page_container, bg="#ffffff", padx=5, pady=5, relief=GROOVE, bd=1)
        self.patient_list_frame.grid(row=1, column=0, sticky="nsew", padx=(0, 10), pady=10)
        self.patient_list_frame.grid_rowconfigure(1, weight=1)
        self.patient_list_frame.grid_columnconfigure(0, weight=1)

        Label(self.patient_list_frame, text="Kayıtlı Hastalar", font=("Arial", 12, "bold"), bg="#ffffff",
              fg="#3498db").grid(row=0, column=0, sticky="w", pady=(0, 10))

        # Hasta Treeview
        patient_scrollbar = Scrollbar(self.patient_list_frame, orient=VERTICAL)
        # Hastalar: (ID, TC No, Ad Soyad, Telefon)
        self.patient_list_tv = ttk.Treeview(self.patient_list_frame, columns=("ID", "TC No", "Ad Soyad"),
                                            show="headings", yscrollcommand=patient_scrollbar.set)

        patient_scrollbar.config(command=self.patient_list_tv.yview)
        patient_scrollbar.grid(row=1, column=1, sticky='ns')
        self.patient_list_tv.grid(row=1, column=0, sticky="nsew")

        self.patient_list_tv.heading("ID", text="ID", anchor=W)
        self.patient_list_tv.heading("TC No", text="TC No", anchor=W)
        self.patient_list_tv.heading("Ad Soyad", text="Ad Soyad", anchor=W)

        self.patient_list_tv.column("ID", width=30, anchor=CENTER)
        self.patient_list_tv.column("TC No", width=100)
        self.patient_list_tv.column("Ad Soyad", width=150)

        self.patient_list_tv.bind("<<TreeviewSelect>>", self.load_patient_to_form)
        self.load_patient_list()

        # --- SÜTUN 1: REÇETE FORMU (ORTA PANEL) ---
        self.recete_form_frame = Frame(self.page_container, bg="#ffffff", padx=15, pady=15, relief=GROOVE, bd=1)
        self.recete_form_frame.grid(row=1, column=1, sticky="nsw", padx=10, pady=10)

        Label(self.recete_form_frame, text="Reçete Oluşturma", font=("Arial", 12, "bold"), bg="#ffffff",
              fg="#3498db").grid(row=0, column=0, columnspan=2, pady=(0, 15))

        # --- Hasta Bilgileri (Görüntüleme) ---
        Label(self.recete_form_frame, text="Seçili TC No:", bg="#ffffff", font=("Arial", 10)).grid(row=1, column=0,
                                                                                                   sticky="w", pady=5)
        self.hasta_tc_display = Label(self.recete_form_frame, text="---", bg="#ecf0f1", font=("Arial", 10, "bold"),
                                      width=15)
        self.hasta_tc_display.grid(row=1, column=1, sticky="ew", padx=10, pady=5)

        Label(self.recete_form_frame, text="Ad Soyad:", bg="#ffffff", font=("Arial", 10)).grid(row=2, column=0,
                                                                                               sticky="w", pady=5)
        self.hasta_ad_display = Label(self.recete_form_frame, text="---", bg="#ecf0f1", font=("Arial", 10, "bold"))
        self.hasta_ad_display.grid(row=2, column=1, sticky="ew", padx=10, pady=5)

        # --- Reçete Temel Bilgileri ---
        Label(self.recete_form_frame, text="Reçete No:", bg="#ffffff", font=("Arial", 10)).grid(row=3, column=0,
                                                                                                sticky="w", pady=5)
        self.recete_no_entry = Entry(self.recete_form_frame, font=("Arial", 10), relief=FLAT, bg="#ecf0f1", width=25)
        self.recete_no_entry.grid(row=3, column=1, sticky="ew", padx=10, pady=5)

        Label(self.recete_form_frame, text="Veriliş Tarihi:", bg="#ffffff", font=("Arial", 10)).grid(row=4, column=0,
                                                                                                     sticky="w", pady=5)
        self.recete_tarih_entry = Entry(self.recete_form_frame, font=("Arial", 10), relief=FLAT, bg="#ecf0f1", width=25)
        self.recete_tarih_entry.insert(0, 'YYYY-MM-DD')
        self.recete_tarih_entry.grid(row=4, column=1, sticky="ew", padx=10, pady=5)

        # --- İLAÇ EKLEME KISMI ---
        Label(self.recete_form_frame, text="--- İlaç Ekle ---", font=("Arial", 10, "bold"), bg="#ffffff",
              fg="#2c3e50").grid(row=5, column=0, columnspan=2, pady=(15, 5))

        # İlaç Seçimi (OptionMenu)
        Label(self.recete_form_frame, text="İlaç Adı:", bg="#ffffff", font=("Arial", 10)).grid(row=6, column=0,
                                                                                               sticky="w", pady=5)
        self.medicine_options = self.db.get_all_medicines()  # (ID, Barkod, Ad, Stok, Fiyat, SKT)
        self.medicine_names = [f"{m[2]} (Stok: {m[3]})" for m in self.medicine_options]
        self.selected_med_var = StringVar(self.recete_form_frame)
        self.selected_med_var.set(self.medicine_names[0] if self.medicine_names else "Stok Yok")

        self.med_opt = OptionMenu(self.recete_form_frame, self.selected_med_var,
                                  *(self.medicine_names if self.medicine_names else ["Stok Yok"]))
        self.med_opt.config(width=18, relief=FLAT, bg="#ecf0f1")
        self.med_opt.grid(row=6, column=1, sticky="ew", padx=10, pady=5)

        # Miktar Girişi
        Label(self.recete_form_frame, text="Miktar:", bg="#ffffff", font=("Arial", 10)).grid(row=7, column=0,
                                                                                             sticky="w", pady=5)
        self.med_miktar_entry = Entry(self.recete_form_frame, font=("Arial", 10), relief=FLAT, bg="#ecf0f1", width=25)
        self.med_miktar_entry.insert(0, 1)
        self.med_miktar_entry.grid(row=7, column=1, sticky="ew", padx=10, pady=5)

        # İlaç Ekle Butonu
        Button(self.recete_form_frame, text="REÇETEYE İLAÇ EKLE", command=self.add_item_to_prescription,
               bg="#3498db", fg="white", font=("Arial", 10, "bold"), relief=FLAT).grid(row=8, column=0, columnspan=2,
                                                                                       pady=(10, 10), padx=5,
                                                                                       sticky="ew")

        # --- Eklenen İlaçları Listeleme (Placeholder) ---
        Label(self.recete_form_frame, text="Eklenen İlaçlar:", font=("Arial", 10, "bold"), bg="#ffffff",
              fg="#2c3e50").grid(row=9, column=0, columnspan=2, pady=(10, 5))

        self.prescription_items_listbox = Listbox(self.recete_form_frame, height=4, width=30, relief=FLAT, bg="#ecf0f1")
        self.prescription_items_listbox.grid(row=10, column=0, columnspan=2, padx=5, pady=5)

        Button(self.recete_form_frame, text="SEÇİLİ İLACI ÇIKAR", command=self.remove_item_from_prescription,
               bg="#e74c3c", fg="white", font=("Arial", 8), relief=FLAT).grid(row=11, column=0, columnspan=2,
                                                                              pady=(5, 10), padx=5, sticky="ew")

        # --- Ana Reçete Kaydet Butonu ---
        self.current_items = {}  # {ilac_id: miktar}
        self.selected_patient_tc = None

        Button(self.recete_form_frame, text="REÇETEYİ KAYDET", command=self.save_prescription_ui,
               bg="#2ecc71", fg="white", font=("Arial", 12, "bold"), relief=FLAT).grid(row=12, column=0, columnspan=2,
                                                                                       pady=(10, 5), padx=5,
                                                                                       sticky="ew")

        # --- SÜTUN 2: TÜM REÇETELER LİSTESİ ---
        self.recete_list_frame = Frame(self.page_container, bg="#ffffff")
        self.recete_list_frame.grid(row=1, column=2, sticky="nsew", pady=10, padx=(10, 0))
        self.recete_list_frame.grid_rowconfigure(0, weight=1)
        self.recete_list_frame.grid_columnconfigure(0, weight=1)

        # Reçete Treeview
        scrollbar = Scrollbar(self.recete_list_frame, orient=VERTICAL)
        self.prescription_list = ttk.Treeview(self.recete_list_frame,
                                              columns=("ID", "R. No", "Hasta Adı", "TC No", "Tarih", "Durum"),
                                              show="headings", yscrollcommand=scrollbar.set)

        scrollbar.config(command=self.prescription_list.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')
        self.prescription_list.grid(row=0, column=0, sticky="nsew")

        self.prescription_list.heading("ID", text="ID", anchor=W)
        self.prescription_list.heading("R. No", text="Reçete No", anchor=W)
        self.prescription_list.heading("Hasta Adı", text="Hasta Adı", anchor=W)
        self.prescription_list.heading("TC No", text="TC No", anchor=W)
        self.prescription_list.heading("Tarih", text="Tarih", anchor=W)
        self.prescription_list.heading("Durum", text="Durum", anchor=W)

        self.prescription_list.column("ID", width=30, anchor=CENTER)
        self.prescription_list.column("R. No", width=80)
        self.prescription_list.column("Hasta Adı", width=150)
        self.prescription_list.column("TC No", width=100)
        self.prescription_list.column("Tarih", width=100, anchor=CENTER)
        self.prescription_list.column("Durum", width=80, anchor=CENTER)

        self.load_prescription_list()

    def load_patient_list(self):
        """Kayıtlı hastaları Treeview'e yükler."""
        for item in self.patient_list_tv.get_children():
            self.patient_list_tv.delete(item)

        patients = self.db.get_patient_list_for_dashboard()
        # Hasta verileri: (ID, TC No, Ad Soyad, Telefon)
        for p in patients:
            # Sadece ID, TC No ve Ad Soyad gösterilir
            self.patient_list_tv.insert('', END, values=(p[0], p[1], p[2]))

    def load_patient_to_form(self, event):
        """Seçilen hastanın bilgilerini forma yükler ve reçete oluşturmaya hazırlar."""
        selected_item = self.patient_list_tv.selection()
        if not selected_item: return

        values = self.patient_list_tv.item(selected_item, 'values')

        tc_no = values[1]
        ad_soyad = values[2]

        self.hasta_tc_display.config(text=tc_no, fg="#2c3e50")
        self.hasta_ad_display.config(text=ad_soyad, fg="#2c3e50")
        self.selected_patient_tc = tc_no  # TC'yi global değişkene kaydet

        self.prescription_items_listbox.delete(0, END)
        self.current_items = {}
        messagebox.showinfo("Seçim", f"Reçete {ad_soyad} için hazırlanacak. Eklemeye başlayın.")

    def add_item_to_prescription(self):
        """Reçeteye ilaç ve miktar ekler."""
        if not self.selected_patient_tc:
            messagebox.showerror("Hata", "Lütfen önce soldaki listeden bir hasta seçin.")
            return

        if self.selected_med_var.get() == "Stok Yok":
            messagebox.showerror("Hata", "Sistemde reçete yazılabilecek ilaç kaydı bulunmamaktadır.")
            return

        try:
            miktar = int(self.med_miktar_entry.get())
            if miktar <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Hata", "Miktar geçerli bir pozitif sayı olmalıdır.")
            return

        selected_med_name_with_stock = self.selected_med_var.get()
        ilac_ad = selected_med_name_with_stock.split(" (Stok:")[0]

        ilac_id = None
        current_stok = 0
        for m in self.medicine_options:
            if m[2] == ilac_ad:
                ilac_id = m[0]
                current_stok = m[3]
                break

        if ilac_id is None:
            messagebox.showerror("Hata", "Seçili ilaç ID'si bulunamadı.")
            return

        # Stok kontrolü (Toplam miktar kontrolü)
        required_total_qty = miktar + self.current_items.get(ilac_id, 0)

        if required_total_qty > current_stok:
            messagebox.showerror("Hata", f"{ilac_ad} için stok yetersiz! (Maksimum {current_stok} adet eklenebilir)")
            return

        # Miktarı güncelle/ekle
        self.current_items[ilac_id] = required_total_qty

        # Listbox'ı güncelle
        self.prescription_items_listbox.delete(0, END)
        for id, qty in self.current_items.items():
            item_name = next(m[2] for m in self.medicine_options if m[0] == id)
            self.prescription_items_listbox.insert(END, f"{item_name} x {qty}")

        self.med_miktar_entry.delete(0, END)
        self.med_miktar_entry.insert(0, 1)

    def remove_item_from_prescription(self):
        """Eklenen ilaçlardan seçili olanı çıkarır."""
        selected_index = self.prescription_items_listbox.curselection()
        if not selected_index:
            messagebox.showerror("Hata", "Lütfen listeden çıkarılacak bir ilaç seçin.")
            return

        selected_text = self.prescription_items_listbox.get(selected_index[0])
        item_name = selected_text.split(" x ")[0]

        ilac_id = next(m[0] for m in self.medicine_options if m[2] == item_name)

        if ilac_id in self.current_items:
            del self.current_items[ilac_id]
            self.prescription_items_listbox.delete(selected_index[0])
            messagebox.showinfo("Çıkarıldı", f"{item_name} reçeteden çıkarıldı.")

        # Güncel Listbox durumunu kontrol et
        if not self.current_items:
            self.prescription_items_listbox.insert(END, "Reçete boş.")

    def save_prescription_ui(self):
        """Reçeteyi ve içerisindeki ilaçları kaydeder."""
        if not self.selected_patient_tc:
            messagebox.showerror("Hata", "Lütfen önce reçete yazmak için bir hasta seçin.")
            return

        recete_no = self.recete_no_entry.get()
        verilis_tarihi = self.recete_tarih_entry.get()
        items_to_save = list(self.current_items.items())

        if not recete_no:
            messagebox.showerror("Hata", "Lütfen reçete numarası girin.")
            return

        if not items_to_save:
            messagebox.showerror("Hata", "Lütfen reçeteye en az bir ilaç ekleyin.")
            return

        # DB'ye kaydetme işlemi (Stok kontrolü DB içinde yapılıyor)
        success, message = self.db.add_prescription_with_items(recete_no, self.selected_patient_tc, verilis_tarihi,
                                                               items_to_save)

        if success:
            messagebox.showinfo("Başarılı", message)

            # Formu temizle ve listeleri güncelle
            self.recete_no_entry.delete(0, END)
            self.prescription_items_listbox.delete(0, END)
            self.current_items = {}
            self.load_prescription_list()
            self.load_medicine_list()  # Stoklar değiştiği için ilaç listesi yenilenmeli
            self.load_patient_list()
            self.selected_patient_tc = None
            self.hasta_tc_display.config(text="---")
            self.hasta_ad_display.config(text="---")

        else:
            messagebox.showerror("Hata", message)

    def load_prescription_list(self):
        for item in self.prescription_list.get_children():
            self.prescription_list.delete(item)

        prescriptions = self.db.get_all_prescriptions()
        for rec in prescriptions:
            self.prescription_list.insert('', END, values=rec)

    # =========================================================================
    # 3. KULLANICI YÖNETİMİ MODÜLÜ (Sadece YÖNETİCİ)
    # =========================================================================

    def add_personnel_ui(self):
        """Yeni personel (varsayılan yetki: personel) kaydını gerçekleştirir."""
        username = self.new_username_entry.get()
        password = self.new_password_entry.get()

        if not (username and password):
            messagebox.showerror("Hata", "Kullanıcı adı ve şifre boş bırakılamaz.")
            return

        success, message = self.db.register_user(username, password)  # Varsayılan yetki 'personel'

        if success:
            messagebox.showinfo("Başarılı", f"Personel '{username}' başarıyla kaydedildi.")
            self.new_username_entry.delete(0, END)
            self.new_password_entry.delete(0, END)
            self.load_user_list()  # Listeyi güncelle
        else:
            messagebox.showerror("Hata", message)

    def show_user_management(self):
        if self.yetki != 'yonetici':
            messagebox.showerror("Yetki Hatası", "Bu işlemi gerçekleştirmeye yetkiniz yoktur.")
            self.show_home_screen()
            return

        self.clear_content_area()
        Label(self.page_container, text="ADMİN | KULLANICI YÖNETİMİ",
              font=("Arial", 18, "bold"), fg="#f39c12", bg="#ecf0f1").grid(row=0, column=0, columnspan=2, pady=(0, 20),
                                                                           sticky="w")

        # --- GRID Ayarları ---
        self.page_container.grid_columnconfigure(0, weight=1)  # Liste
        self.page_container.grid_columnconfigure(1, weight=0)  # Kontrol ve Ekleme Paneli
        self.page_container.grid_rowconfigure(1, weight=1)

        # --- SOL PANEL: KULLANICI LİSTESİ ---
        user_list_frame = Frame(self.page_container, bg="#ffffff")
        user_list_frame.grid(row=1, column=0, sticky="nsew", pady=10, padx=(0, 10))
        user_list_frame.grid_rowconfigure(0, weight=1)
        user_list_frame.grid_columnconfigure(0, weight=1)

        user_scrollbar = Scrollbar(user_list_frame, orient=VERTICAL)
        # Artık hem personel hem hastalar listelenir.
        self.user_list = ttk.Treeview(user_list_frame, columns=("ID", "Kullanıcı Adı", "Yetki"),
                                      show="headings", yscrollcommand=user_scrollbar.set)

        user_scrollbar.config(command=self.user_list.yview)
        user_scrollbar.grid(row=0, column=1, sticky='ns')

        self.user_list.grid(row=0, column=0, sticky="nsew")

        self.user_list.heading("ID", text="ID", anchor=W)
        self.user_list.heading("Kullanıcı Adı", text="Kullanıcı Adı", anchor=W)
        self.user_list.heading("Yetki", text="Yetki", anchor=W)

        self.user_list.column("ID", width=30, anchor=CENTER)
        self.user_list.column("Kullanıcı Adı", width=150)
        self.user_list.column("Yetki", width=100, anchor=CENTER)

        self.user_list.bind("<<TreeviewSelect>>", self.load_user_data_to_control_panel)
        self.load_user_list()

        # --- SAĞ PANEL: KONTROL ve EKLEME ---
        self.control_panel_container = Frame(self.page_container, bg="#ecf0f1")
        self.control_panel_container.grid(row=1, column=1, sticky="nsw", pady=10, padx=(10, 0))

        # --- 1. Yeni Kullanıcı Ekleme Formu ---
        self.user_add_frame = Frame(self.control_panel_container, bg="#ffffff", padx=15, pady=15, relief=GROOVE, bd=1)
        self.user_add_frame.grid(row=0, column=0, sticky="new", pady=(0, 15))
        self.user_add_frame.grid_columnconfigure(1, weight=1)

        Label(self.user_add_frame, text="YENİ PERSONEL EKLE", font=("Arial", 12, "bold"), bg="#ffffff",
              fg="#2ecc71").grid(row=0, column=0, columnspan=2, pady=(0, 15))

        # Kullanıcı Adı
        Label(self.user_add_frame, text="Kullanıcı Adı:", bg="#ffffff", font=("Arial", 10)).grid(row=1, column=0,
                                                                                                 sticky="w", pady=5)
        self.new_username_entry = Entry(self.user_add_frame, font=("Arial", 10), relief=FLAT, bg="#ecf0f1", width=20)
        self.new_username_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=5)

        # Şifre
        Label(self.user_add_frame, text="Şifre:", bg="#ffffff", font=("Arial", 10)).grid(row=2, column=0, sticky="w",
                                                                                         pady=5)
        self.new_password_entry = Entry(self.user_add_frame, font=("Arial", 10), show="*", relief=FLAT, bg="#ecf0f1",
                                        width=20)
        self.new_password_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=5)

        Button(self.user_add_frame, text="PERSONEL KAYDET", command=self.add_personnel_ui,
               bg="#2ecc71", fg="white", font=("Arial", 10, "bold"), relief=FLAT).grid(row=3, column=0, columnspan=2,
                                                                                       pady=(15, 5), sticky="ew")

        # --- 2. Seçili Kullanıcı Kontrol Paneli (Mevcut Kod) ---
        self.user_control_frame = Frame(self.control_panel_container, bg="#ffffff", padx=15, pady=15, relief=GROOVE,
                                        bd=1)
        self.user_control_frame.grid(row=1, column=0, sticky="nsw")

        Label(self.user_control_frame, text="Seçili Kullanıcı İşlemleri", font=("Arial", 12, "bold"), bg="#ffffff",
              fg="#f39c12").grid(row=0, column=0, columnspan=2, pady=(0, 15))

        Label(self.user_control_frame, text="Kullanıcı ID:", bg="#ffffff", font=("Arial", 10)).grid(row=1, column=0,
                                                                                                    sticky="w", pady=5)
        self.selected_user_id = Label(self.user_control_frame, text="--", bg="#ecf0f1", font=("Arial", 10, "bold"),
                                      width=15)
        self.selected_user_id.grid(row=1, column=1, sticky="ew", padx=10, pady=5)

        Label(self.user_control_frame, text="Kullanıcı Adı:", bg="#ffffff", font=("Arial", 10)).grid(row=2, column=0,
                                                                                                     sticky="w", pady=5)
        self.selected_username = Label(self.user_control_frame, text="--", bg="white", font=("Arial", 10))
        self.selected_username.grid(row=2, column=1, sticky="ew", padx=10, pady=5)

        Label(self.user_control_frame, text="Yeni Yetki:", bg="#ffffff", font=("Arial", 10)).grid(row=3, column=0,
                                                                                                  sticky="w", pady=15)
        self.new_privilege_var = StringVar(self.user_control_frame)
        self.new_privilege_var.set("personel")
        self.privilege_options = OptionMenu(self.user_control_frame, self.new_privilege_var, "personel", "yonetici")
        self.privilege_options.config(width=12, relief=FLAT, bg="#ecf0f1")
        self.privilege_options.grid(row=3, column=1, sticky="ew", padx=10, pady=15)

        # Butonlar (Referansları burada tanımlıyoruz)
        self.btn_update_privilege = Button(self.user_control_frame, text="YETKİ GÜNCELLE",
                                           command=self.update_user_privilege_ui,
                                           bg="#f39c12", fg="white", font=("Arial", 10, "bold"), relief=FLAT)
        self.btn_update_privilege.grid(row=4, column=0, columnspan=2, pady=(20, 10), sticky="ew")

        self.btn_delete_user = Button(self.user_control_frame, text="KULLANICI SİL", command=self.delete_user_ui,
                                      bg="#e74c3c", fg="white", font=("Arial", 10, "bold"), relief=FLAT)
        self.btn_delete_user.grid(row=5, column=0, columnspan=2, pady=10, sticky="ew")

        # İlk açılışta butonları devre dışı bırak
        self.btn_update_privilege.config(state=DISABLED)
        self.btn_delete_user.config(state=DISABLED)

    def load_user_list(self):
        """Veri tabanındaki tüm kullanıcıları Treeview'e yükler."""
        for item in self.user_list.get_children():
            self.user_list.delete(item)

        # Tüm kullanıcıları çekiyoruz (db_manager.py'deki sorgu ile)
        users = self.db.get_all_users()
        for user in users:
            self.user_list.insert('', END, values=user)

    def load_user_data_to_control_panel(self, event):
        """Seçilen kullanıcının verilerini kontrol paneline yükler ve yetkiyi kilitler."""
        selected_item = self.user_list.selection()
        if not selected_item: return

        values = self.user_list.item(selected_item, 'values')

        user_id, username, yetki = values

        self.selected_user_id.config(text=user_id)
        self.selected_username.config(text=username)
        self.new_privilege_var.set(yetki)

        # --- KONTROL: Eğer kullanıcı hastaysa, yetki değiştirmeyi/silmeyi yasakla ---
        is_patient = (yetki == 'hasta')

        # Butonları ve OptionMenu'yu kontrol et
        state = DISABLED if is_patient else NORMAL

        self.privilege_options.config(state=state)
        self.btn_update_privilege.config(state=state)
        self.btn_delete_user.config(state=state)

        if is_patient:
            pass

    def update_user_privilege_ui(self):
        user_id = self.selected_user_id.cget("text")
        new_yetki = self.new_privilege_var.get()

        if user_id == "--":
            messagebox.showerror("Hata", "Lütfen listeden bir kullanıcı seçin.")
            return

        success, message = self.db.update_user_privilege(user_id, new_yetki)

        if success:
            messagebox.showinfo("Başarılı", message)
            self.load_user_list()
        else:
            messagebox.showerror("Hata", message)

    def delete_user_ui(self):
        user_id = self.selected_user_id.cget("text")
        username = self.selected_username.cget("text")

        if user_id == "--":
            messagebox.showerror("Hata", "Lütfen listeden bir kullanıcı seçin.")
            return

        if messagebox.askyesno("Onay", f"{username} kullanıcısını silmek istediğinizden emin misiniz?"):
            success, message = self.db.delete_user(user_id)
            if success:
                messagebox.showinfo("Başarılı", message)
                self.selected_user_id.config(text="--")
                self.selected_username.config(text="--")
                self.load_user_list()
            else:
                messagebox.showerror("Hata", message)