import sqlite3
import hashlib

DB_NAME = 'eczane_otomasyon.db'


class DatabaseManager:
    """Veri tabanı bağlantılarını ve temel işlemleri yönetir."""

    def __init__(self):
        self.conn = sqlite3.connect(DB_NAME)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        """Uygulama başladığında gerekli tabloları oluşturur."""

        # 1. KULLANICILAR Tablosu: Giriş/Kayıt için (Yetki: yonetici, personel, hasta)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS KULLANICILAR (
                id INTEGER PRIMARY KEY,
                kullanici_adi TEXT UNIQUE NOT NULL, -- Personel için isim, Hasta için TC No
                sifre_hash TEXT NOT NULL,
                yetki TEXT NOT NULL DEFAULT 'personel'
            )
        ''')

        # 2. İLAÇLAR Tablosu: Stok yönetimi için
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS ILACLAR (
                id INTEGER PRIMARY KEY,
                barkod_no TEXT UNIQUE NOT NULL,
                ad TEXT NOT NULL,
                stok_miktari INTEGER NOT NULL,
                fiyat REAL NOT NULL,
                son_kullanma_tarihi DATE 
            )
        ''')

        # 3. HASTALAR Tablosu: Reçete için hasta bilgilerini tutar
        # Düzeltme: Yanlış yazılan 'NOTTINGS' kelimesi 'NOT NULL' olarak düzeltildi.
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS HASTALAR (
                id INTEGER PRIMARY KEY,
                tc_no TEXT UNIQUE NOT NULL, 
                ad_soyad TEXT NOT NULL,
                telefon TEXT
            )
        ''')

        # 4. REÇETELER Tablosu:
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS RECETELER (
                id INTEGER PRIMARY KEY,
                recete_no TEXT UNIQUE NOT NULL,
                hasta_id INTEGER NOT NULL,
                verilis_tarihi DATE NOT NULL,
                durum TEXT NOT NULL DEFAULT 'Onaylandı', 
                FOREIGN KEY (hasta_id) REFERENCES HASTALAR(id)
            )
        ''')

        # 5. REÇETE_ICERIK Tablosu:
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS RECETE_ICERIK (
                id INTEGER PRIMARY KEY,
                recete_id INTEGER NOT NULL,
                ilac_id INTEGER NOT NULL,
                miktar INTEGER NOT NULL,
                FOREIGN KEY (recete_id) REFERENCES RECETELER(id),
                FOREIGN KEY (ilac_id) REFERENCES ILACLAR(id)
            )
        ''')

        self.conn.commit()
        self.add_default_admin()

    def add_default_admin(self):
        admin_pass = hashlib.sha256("admin123".encode()).hexdigest()
        self.cursor.execute("SELECT * FROM KULLANICILAR WHERE kullanici_adi='admin'")
        if not self.cursor.fetchone():
            self.cursor.execute("INSERT INTO KULLANICILAR (kullanici_adi, sifre_hash, yetki) VALUES (?, ?, ?)",
                                ('admin', admin_pass, 'yonetici'))
            self.conn.commit()
            print("Varsayılan yönetici hesabı eklendi: admin / admin123")

    def register_user(self, username, password):
        try:
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            self.cursor.execute("INSERT INTO KULLANICILAR (kullanici_adi, sifre_hash) VALUES (?, ?)",
                                (username, password_hash))
            self.conn.commit()
            return True, "Kayıt Başarılı!"
        except sqlite3.IntegrityError:
            return False, "Kullanıcı adı zaten mevcut."
        except Exception as e:
            return False, f"Hata: {e}"

    def check_login(self, username, password):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        self.cursor.execute(
            "SELECT yetki FROM KULLANICILAR WHERE kullanici_adi=? AND sifre_hash=? AND yetki IN ('personel', 'yonetici')",
            (username, password_hash))
        result = self.cursor.fetchone()
        if result:
            return True, result[0]
        else:
            return False, None

    def add_medicine(self, barkod, ad, stok, fiyat, son_kullanma_tarihi):
        try:
            self.cursor.execute(
                "INSERT INTO ILACLAR (barkod_no, ad, stok_miktari, fiyat, son_kullanma_tarihi) VALUES (?, ?, ?, ?, ?)",
                (barkod, ad, stok, fiyat, son_kullanma_tarihi))
            self.conn.commit()
            return True, "İlaç başarıyla eklendi."
        except sqlite3.IntegrityError:
            return False, "Hata: Bu Barkod Numarası zaten mevcut."
        except Exception as e:
            return False, f"Hata: {e}"

    def get_all_medicines(self):
        self.cursor.execute("SELECT id, barkod_no, ad, stok_miktari, fiyat, son_kullanma_tarihi FROM ILACLAR")
        return self.cursor.fetchall()

    def update_medicine(self, id, barkod, ad, stok, fiyat, son_kullanma_tarihi):
        try:
            self.cursor.execute("""
                UPDATE ILACLAR SET barkod_no=?, ad=?, stok_miktari=?, fiyat=?, son_kullanma_tarihi=?
                WHERE id=?
            """, (barkod, ad, stok, fiyat, son_kullanma_tarihi, id))
            self.conn.commit()
            if self.cursor.rowcount == 0:
                return False, "Güncellenecek ilaç bulunamadı."
            return True, "İlaç bilgileri başarıyla güncellendi."
        except sqlite3.IntegrityError:
            return False, "Hata: Bu Barkod Numarası zaten mevcut."
        except Exception as e:
            return False, f"Hata: Güncelleme sırasında beklenmeyen hata: {e}"

    def delete_medicine(self, id):
        try:
            self.cursor.execute("DELETE FROM ILACLAR WHERE id=?", (id,))
            self.conn.commit()
            if self.cursor.rowcount == 0:
                return False, "Silinecek ilaç bulunamadı."
            return True, "İlaç başarıyla silindi."
        except Exception as e:
            return False, f"Hata: {e}"

    def get_patient_list_for_dashboard(self):
        self.cursor.execute("SELECT id, tc_no, ad_soyad, telefon FROM HASTALAR ORDER BY ad_soyad")
        return self.cursor.fetchall()

    def add_patient_and_user(self, tc_no, ad_soyad, password):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        try:
            self.conn.execute("BEGIN TRANSACTION")
            self.cursor.execute("INSERT INTO HASTALAR (tc_no, ad_soyad, telefon) VALUES (?, ?, ?)",
                                (tc_no, ad_soyad, None))
            self.cursor.execute("INSERT INTO KULLANICILAR (kullanici_adi, sifre_hash, yetki) VALUES (?, ?, ?)",
                                (tc_no, password_hash, 'hasta'))
            self.conn.commit()
            return True, "Hasta ve kullanıcı kaydı başarıyla tamamlandı."
        except sqlite3.IntegrityError:
            self.conn.rollback()
            return False, "Hata: Bu T.C. Kimlik No veya kullanıcı adı zaten sistemde mevcut."
        except Exception as e:
            self.conn.rollback()
            return False, f"Beklenmedik Hata: {e}"

    def check_patient_login(self, tc_no, password):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        self.cursor.execute("SELECT id FROM KULLANICILAR WHERE kullanici_adi=? AND sifre_hash=? AND yetki='hasta'",
                            (tc_no, password_hash))
        user_result = self.cursor.fetchone()
        if user_result:
            self.cursor.execute("SELECT id, tc_no, ad_soyad FROM HASTALAR WHERE tc_no=?", (tc_no,))
            patient_result = self.cursor.fetchone()
            if patient_result:
                return True, {'id': patient_result[0], 'tc_no': patient_result[1], 'ad_soyad': patient_result[2],
                              'yetki': 'hasta'}
            else:
                return False, None
        else:
            return False, None

    def get_patient_by_tc(self, tc_no):
        self.cursor.execute("SELECT id, tc_no, ad_soyad, telefon FROM HASTALAR WHERE tc_no=?", (tc_no,))
        return self.cursor.fetchone()

    def add_prescription_with_items(self, recete_no, tc_no, verilis_tarihi, items):
        patient = self.get_patient_by_tc(tc_no)
        if not patient:
            return False, "Hata: Önce hastayı kaydetmelisiniz (TC No bulunamadı)."
        hasta_id = patient[0]
        try:
            self.conn.execute("BEGIN TRANSACTION")
            self.cursor.execute("INSERT INTO RECETELER (recete_no, hasta_id, verilis_tarihi) VALUES (?, ?, ?)",
                                (recete_no, hasta_id, verilis_tarihi))
            recete_id = self.cursor.lastrowid
            for ilac_id, miktar in items:
                self.cursor.execute("SELECT stok_miktari FROM ILACLAR WHERE id=?", (ilac_id,))
                current_stok = self.cursor.fetchone()[0]
                if current_stok < miktar:
                    self.conn.rollback()
                    return False, f"Hata: Stokta {ilac_id} ID'li ilaçtan yeterli miktar yok. ({current_stok} adet kaldı)"
                self.cursor.execute("UPDATE ILACLAR SET stok_miktari = stok_miktari - ? WHERE id=?", (miktar, ilac_id))
                self.cursor.execute("INSERT INTO RECETE_ICERIK (recete_id, ilac_id, miktar) VALUES (?, ?, ?)",
                                    (recete_id, ilac_id, miktar))
            self.conn.commit()
            return True, "Reçete ve ilaçlar başarıyla kaydedildi ve stok güncellendi."
        except sqlite3.IntegrityError:
            self.conn.rollback()
            return False, "Hata: Bu Reçete Numarası zaten mevcut."
        except Exception as e:
            self.conn.rollback()
            return False, f"Beklenmedik Hata: {e}"

    def get_all_prescriptions(self):
        self.cursor.execute("""
            SELECT 
                R.id, R.recete_no, H.ad_soyad, H.tc_no, R.verilis_tarihi, R.durum
            FROM RECETELER R
            JOIN HASTALAR H ON R.hasta_id = H.id
            ORDER BY R.verilis_tarihi DESC
        """)
        return self.cursor.fetchall()

    def get_prescriptions_by_patient_tc(self, tc_no):
        self.cursor.execute("SELECT id FROM HASTALAR WHERE tc_no=?", (tc_no,))
        patient_id_result = self.cursor.fetchone()
        if not patient_id_result:
            return []
        hasta_id = patient_id_result[0]
        self.cursor.execute("""
            SELECT 
                R.id, R.recete_no, R.verilis_tarihi, R.durum
            FROM RECETELER R
            WHERE R.hasta_id = ?
            ORDER BY R.verilis_tarihi DESC
        """, (hasta_id,))
        return self.cursor.fetchall()

    def get_prescription_details(self, recete_id):
        self.cursor.execute("""
            SELECT 
                I.ad, 
                IC.miktar
            FROM RECETE_ICERIK IC
            JOIN ILACLAR I ON IC.ilac_id = I.id
            WHERE IC.recete_id = ?
        """, (recete_id,))
        return self.cursor.fetchall()

    def get_dashboard_stats(self):
        """Ana Panel için temel istatistikleri toplar."""
        stats = {}
        self.cursor.execute("SELECT COUNT(id) FROM ILACLAR")
        stats['total_medicines'] = self.cursor.fetchone()[0]
        self.cursor.execute("SELECT COUNT(id) FROM ILACLAR WHERE stok_miktari <= 10")
        stats['critical_stock_count'] = self.cursor.fetchone()[0]
        self.cursor.execute("SELECT COUNT(id) FROM RECETELER WHERE durum='Hazırlanıyor'")
        stats['pending_prescriptions'] = self.cursor.fetchone()[0]
        self.cursor.execute("SELECT COUNT(id) FROM HASTALAR")
        stats['total_patients'] = self.cursor.fetchone()[0]
        return stats

    # --- KULLANICI YÖNETİMİ METOTLARI (Personel/Admin) ---

    def get_all_users(self):
        """Tüm kullanıcıları (Admin hariç, yetki fark etmeksizin) listeler."""
        # Sorgu: Admin hariç, yetkisi ne olursa olsun (personel, yonetici, hasta) tüm kullanıcıları çeker.
        self.cursor.execute(
            "SELECT id, kullanici_adi, yetki FROM KULLANICILAR WHERE kullanici_adi != 'admin' ORDER BY yetki DESC, kullanici_adi ASC")
        return self.cursor.fetchall()

    def update_user_privilege(self, user_id, new_yetki):
        try:
            self.cursor.execute("UPDATE KULLANICILAR SET yetki=? WHERE id=?", (new_yetki, user_id))
            self.conn.commit()
            if self.cursor.rowcount == 0:
                return False, "Kullanıcı bulunamadı."
            return True, "Kullanıcı yetkisi başarıyla güncellendi."
        except Exception as e:
            return False, f"Hata: {e}"

    def delete_user(self, user_id):
        try:
            self.cursor.execute("DELETE FROM KULLANICILAR WHERE id=?", (user_id,))
            self.conn.commit()
            if self.cursor.rowcount == 0:
                return False, "Kullanıcı bulunamadı."
            return True, "Kullanıcı başarıyla silindi."
        except Exception as e:
            return False, f"Hata: {e}"

    def close(self):
        self.conn.close()