from tkinter import *
from tkinter import messagebox
from db_manager import DatabaseManager
from dashboard import DashboardUI
from patient_dashboard import PatientDashboardUI
import hashlib


# --- GİRİŞ DOĞRULAMA METOTLARI ---

def is_valid_tc(P):
    """
    T.C. Kimlik No kısıtlaması:
    1. Sadece rakam olmalı.
    2. Maksimum 11 hane olmalı.
    P: Entry widget'ının yeni değeri.
    """
    if P.isdigit() or P == "":
        return len(P) <= 11
    return False


def is_valid_name(P):
    """
    Ad Soyad kısıtlaması:
    1. Sadece harf, boşluk veya Türkçe karakterler (ç, Ç, ğ, Ğ, ı, İ, ö, Ö, ş, Ş, ü, Ü) içerebilir.
    """
    allowed_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZğĞüÜşŞıİöÖçÇ "
    if all(c in allowed_chars for c in P):
        return True
    return False


# =========================================================================
# 1. KAYIT PENCERESİ (RegisterWindow) - Sadece Hasta Kaydı İçin
# =========================================================================

class RegisterWindow:
    def __init__(self, master):
        self.master = master
        self.db = DatabaseManager()

        master.title("Yeni Kullanıcı Kaydı")

        app_width = 450
        app_height = 350
        screen_width = master.winfo_screenwidth()
        screen_height = master.winfo_screenheight()
        x = (screen_width / 2) - (app_width / 2)
        y = (screen_height / 2) - (app_height / 2)
        master.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')

        master.resizable(False, False)

        register_frame = Frame(master, padx=20, pady=20, bg="#f4f7f6", relief=GROOVE, bd=1)
        register_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        master.grid_columnconfigure(0, weight=1)

        register_frame.grid_columnconfigure(0, weight=1)
        register_frame.grid_columnconfigure(1, weight=1)

        Label(register_frame, text="Yeni Hasta Kaydı", font=("Arial", 14, "bold"), bg="#f4f7f6").grid(row=0,
                                                                                                      column=0,
                                                                                                      columnspan=2,
                                                                                                      pady=10)

        # Tkinter'ın doğrulama sistemini tanımla
        vcmd_tc = master.register(is_valid_tc)
        vcmd_name = master.register(is_valid_name)

        # Hasta Kaydı İçin Alanlar
        Label(register_frame, text="T.C. Kimlik No:", font=("Arial", 10), bg="#f4f7f6").grid(row=1, column=0,
                                                                                             sticky="e",
                                                                                             padx=5, pady=5)
        self.tc_entry = Entry(register_frame, font=("Arial", 12), relief=FLAT, bg="#ecf0f1",
                              validate='key', validatecommand=(vcmd_tc, '%P'))  # TC Kısıtlaması
        self.tc_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=5)

        Label(register_frame, text="Ad Soyad:", font=("Arial", 10), bg="#f4f7f6").grid(row=2, column=0, sticky="e",
                                                                                       padx=5, pady=5)
        self.name_entry = Entry(register_frame, font=("Arial", 12), relief=FLAT, bg="#ecf0f1",
                                validate='key', validatecommand=(vcmd_name, '%P'))  # İsim Kısıtlaması
        self.name_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=5)

        # Şifre Alanı
        Label(register_frame, text="Şifre:", font=("Arial", 10), bg="#f4f7f6").grid(row=3, column=0, sticky="e", padx=5,
                                                                                    pady=5)
        self.password_entry = Entry(register_frame, font=("Arial", 12), show="*", relief=FLAT, bg="#ecf0f1")
        self.password_entry.grid(row=3, column=1, sticky="ew", padx=5, pady=5)

        Label(register_frame, text="Şifre Tekrar:", font=("Arial", 10), bg="#f4f7f6").grid(row=4, column=0, sticky="e",
                                                                                           padx=5, pady=5)
        self.password_confirm_entry = Entry(register_frame, font=("Arial", 12), show="*", relief=FLAT, bg="#ecf0f1")
        self.password_confirm_entry.grid(row=4, column=1, sticky="ew", padx=5, pady=5)

        # Kayıt Butonu
        register_btn = Button(register_frame, text="Kaydı Tamamla (Hasta)",
                              command=self.handle_patient_registration,
                              bg="#3498db", fg="white", font=("Arial", 12, "bold"),
                              relief=FLAT)
        register_btn.grid(row=5, column=0, columnspan=2, pady=20, ipadx=10)

    def handle_patient_registration(self):
        """Hasta kaydını gerçekleştirir (Hastanın hem hasta hem de kullanıcı olarak kaydı)."""
        tc_no = self.tc_entry.get()
        ad_soyad = self.name_entry.get()
        password = self.password_entry.get()
        password_confirm = self.password_confirm_entry.get()

        # Ekstra zorunlu alan ve hane kontrolü
        if len(tc_no) != 11:
            messagebox.showerror("Hata", "T.C. Kimlik Numarası 11 hane olmalıdır.")
            return

        if not ad_soyad:
            messagebox.showerror("Hata", "Ad Soyad boş bırakılamaz.")
            return

        if password != password_confirm:
            messagebox.showerror("Hata", "Şifreler eşleşmiyor.")
            return

        success_patient, msg_patient = self.db.add_patient_and_user(tc_no, ad_soyad, password)

        if success_patient:
            messagebox.showinfo("Başarılı", msg_patient)
            self.master.destroy()
        else:
            messagebox.showerror("Hata", msg_patient)

        self.db.close()


# =========================================================================
# 2. PERSONEL/ADMİN GİRİŞİ (LoginScreen) - Değişiklik Yok
# =========================================================================

class LoginScreen:
    def __init__(self, master):
        self.master = master
        master.title("Eczane Otomasyon Sistemi | Personel Girişi")

        app_width = 600
        app_height = 450

        self.db = DatabaseManager()

        screen_width = master.winfo_screenwidth()
        screen_height = master.winfo_screenheight()
        x = (screen_width / 2) - (app_width / 2)
        y = (screen_height / 2) - (app_height / 2)
        master.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')

        master.grid_columnconfigure(0, weight=1)
        master.grid_rowconfigure(0, weight=1)

        self.main_frame = Frame(master, bg="#ecf0f1")
        self.main_frame.grid(row=0, column=0, sticky="nsew")

        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)

        self.create_center_login_panel()

    def create_center_login_panel(self):
        self.login_frame = Frame(self.main_frame, bg="white", padx=50, pady=40, relief=GROOVE, bd=1)
        self.login_frame.grid(row=0, column=0, sticky="")

        self.login_frame.grid_columnconfigure(0, weight=1)
        self.login_frame.grid_columnconfigure(1, weight=1)
        self.login_frame.grid_columnconfigure(2, weight=1)

        row_count = 0

        Label(self.login_frame, text="Eczane Stok & Reçete Otomasyonu",
              font=("Arial", 16, "bold"), bg="white", fg="#2c3e50").grid(row=row_count, column=0, columnspan=3,
                                                                         pady=(0, 10))
        row_count += 1

        Label(self.login_frame, text="Personel Girişi",
              font=("Arial", 14, "bold"), bg="white", fg="#3498db").grid(row=row_count, column=0, columnspan=3,
                                                                         pady=(10, 30))
        row_count += 1

        input_frame = Frame(self.login_frame, bg="white")
        input_frame.grid(row=row_count, column=1, sticky="nsew")

        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        Label(input_frame, text="Kullanıcı Adı:", font=("Arial", 10), bg="white").grid(row=0, column=0,
                                                                                       sticky="w", padx=5, pady=10)

        self.username_entry = Entry(input_frame, font=("Arial", 12), relief=FLAT, bg="#ecf0f1", width=25)
        self.username_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=10)

        Label(input_frame, text="Şifre:", font=("Arial", 10), bg="white").grid(row=1, column=0, sticky="w",
                                                                               padx=5, pady=10)

        self.password_entry = Entry(input_frame, font=("Arial", 12), show="*", relief=FLAT, bg="#ecf0f1", width=25)
        self.password_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=10)

        row_count += 1

        login_button = Button(self.login_frame, text="Giriş Yap",
                              command=self.handle_login,
                              bg="#2ecc71", fg="white", font=("Arial", 12, "bold"),
                              cursor="hand2", relief=FLAT, bd=0)
        login_button.grid(row=row_count, column=1, pady=(30, 10), ipadx=40, ipady=8)
        row_count += 1

        Button(self.login_frame, text="Giriş Seçimine Dön",
               command=self.open_chooser,
               bg="#34495e", fg="white", font=("Arial", 10),
               cursor="hand2", relief=FLAT, bd=0).grid(row=row_count, column=1, pady=(10, 0), ipadx=10, ipady=3)

    def open_chooser(self):
        """Giriş Seçim Ekranına döner."""
        self.master.destroy()
        from login_chooser import LoginChooser
        root = Tk()
        LoginChooser(root)
        root.mainloop()

    def handle_login(self):
        """Personel Girişi: Başarılı olursa Personel/Admin Dashboard'u açar."""
        username = self.username_entry.get()
        password = self.password_entry.get()

        success, yetki = self.db.check_login(username, password)

        if success and yetki in ['personel', 'yonetici']:  # Sadece personel/admin girebilir
            messagebox.showinfo("Başarılı", f"Giriş Başarılı! Yetki: {yetki.upper()}")

            try:
                from main import start_app
            except ImportError:
                messagebox.showerror("Hata", "Uygulama başlatma modülü bulunamadı!")
                return

            self.master.destroy()
            root_dashboard = Tk()
            DashboardUI(root_dashboard, yetki, start_app)

        else:
            messagebox.showerror("Hata", "Kullanıcı adı veya şifre hatalı. Yetkiniz yok.")
            self.db.close()


# =========================================================================
# 3. HASTA GİRİŞİ (PatientLoginScreen)
# =========================================================================

class PatientLoginScreen:
    def __init__(self, master):
        self.master = master
        master.title("Eczane Otomasyon Sistemi | Hasta Girişi")

        app_width = 600
        app_height = 450

        self.db = DatabaseManager()

        screen_width = master.winfo_screenwidth()
        screen_height = master.winfo_screenheight()
        x = (screen_width / 2) - (app_width / 2)
        y = (screen_height / 2) - (app_height / 2)
        master.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')

        master.grid_columnconfigure(0, weight=1)
        master.grid_rowconfigure(0, weight=1)

        self.main_frame = Frame(master, bg="#ecf0f1")
        self.main_frame.grid(row=0, column=0, sticky="nsew")

        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)

        self.create_center_login_panel()

    def create_center_login_panel(self):
        self.login_frame = Frame(self.main_frame, bg="white", padx=50, pady=40, relief=GROOVE, bd=1)
        self.login_frame.grid(row=0, column=0, sticky="")

        self.login_frame.grid_columnconfigure(0, weight=1)
        self.login_frame.grid_columnconfigure(1, weight=1)
        self.login_frame.grid_columnconfigure(2, weight=1)

        row_count = 0

        Label(self.login_frame, text="Eczane Stok & Reçete Otomasyonu",
              font=("Arial", 16, "bold"), bg="white", fg="#2c3e50").grid(row=row_count, column=0, columnspan=3,
                                                                         pady=(0, 10))
        row_count += 1

        Label(self.login_frame, text="Hasta Girişi",
              font=("Arial", 14, "bold"), bg="white", fg="#e74c3c").grid(row=row_count, column=0, columnspan=3,
                                                                         pady=(10, 30))
        row_count += 1

        input_frame = Frame(self.login_frame, bg="white")
        input_frame.grid(row=row_count, column=1, sticky="nsew")

        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        # Tkinter'ın doğrulama sistemini tanımla (Bu pencere ana pencere olduğu için doğrudan master kullanılır)
        vcmd_tc = self.master.register(is_valid_tc)

        # Kullanıcı Adı yerine T.C. Kimlik No kullanılır
        Label(input_frame, text="T.C. Kimlik No:", font=("Arial", 10), bg="white").grid(row=0, column=0,
                                                                                        sticky="w", padx=5, pady=10)

        self.tc_entry = Entry(input_frame, font=("Arial", 12), relief=FLAT, bg="#ecf0f1", width=25,
                              validate='key', validatecommand=(vcmd_tc, '%P'))  # TC Kısıtlaması
        self.tc_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=10)

        Label(input_frame, text="Şifre:", font=("Arial", 10), bg="white").grid(row=1, column=0, sticky="w",
                                                                               padx=5, pady=10)

        self.password_entry = Entry(input_frame, font=("Arial", 12), show="*", relief=FLAT, bg="#ecf0f1", width=25)
        self.password_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=10)

        row_count += 1

        login_button = Button(self.login_frame, text="Giriş Yap",
                              command=self.handle_login,
                              bg="#e74c3c", fg="white", font=("Arial", 12, "bold"),
                              cursor="hand2", relief=FLAT, bd=0)
        login_button.grid(row=row_count, column=1, pady=(30, 10), ipadx=40, ipady=8)
        row_count += 1

        # Kayıt Butonu (Hasta Kaydı)
        Button(self.login_frame, text="Kayıt Ol",
               command=self.open_register_window,
               bg="#3498db", fg="white", font=("Arial", 10),
               cursor="hand2", relief=FLAT, bd=0).grid(row=row_count, column=1, pady=(10, 5))
        row_count += 1

        # Geri Dönüş Butonu
        Button(self.login_frame, text="Giriş Seçimine Dön",
               command=self.open_chooser,
               bg="#34495e", fg="white", font=("Arial", 10),
               cursor="hand2", relief=FLAT, bd=0).grid(row=row_count, column=1, pady=(5, 0))

    def open_chooser(self):
        """Giriş Seçim Ekranına döner."""
        self.master.destroy()
        from login_chooser import LoginChooser
        root = Tk()
        LoginChooser(root)
        root.mainloop()

    def open_register_window(self):
        """Kayıt Penceresini açar."""
        register_window = Toplevel(self.master)
        RegisterWindow(register_window)
        register_window.grab_set()

    def handle_login(self):
        """Hasta Girişi: Başarılı olursa Hasta Dashboard'u açar."""
        tc_no = self.tc_entry.get()
        password = self.password_entry.get()

        if len(tc_no) != 11:
            messagebox.showerror("Hata", "T.C. Kimlik Numarası 11 hane olmalıdır.")
            return

        success, patient_data = self.db.check_patient_login(tc_no, password)

        if success:
            messagebox.showinfo("Başarılı", f"Hoş Geldiniz, {patient_data['ad_soyad']}!")

            try:
                from main import start_app
            except ImportError:
                messagebox.showerror("Hata", "Uygulama başlatma modülü bulunamadı!")
                return

            self.master.destroy()
            root_dashboard = Tk()
            # Hasta Dashboard'una hasta verilerini gönderiyoruz
            PatientDashboardUI(root_dashboard, patient_data, start_app)

        else:
            messagebox.showerror("Hata", "T.C. Kimlik No veya şifre hatalı.")
            self.db.close()