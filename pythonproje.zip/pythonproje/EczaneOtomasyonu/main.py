from tkinter import *
# Yeni modülü import ediyoruz
from login_chooser import LoginChooser


def start_app():
    """Uygulamayı sıfırdan başlatan ana fonksiyon."""
    global root

    try:
        if 'root' in globals() and root.winfo_exists():
            root.destroy()
    except Exception:
        pass

    root = Tk()
    # LoginChooser'ı başlat
    LoginChooser(root)
    root.mainloop()


if __name__ == "__main__":
    start_app()