from tkinter import *
from tkinter import messagebox
from login_auth import LoginScreen, PatientLoginScreen
from patient_dashboard import PatientDashboardUI


# start_app importu burada olmamalı.

class LoginChooser:
    """Uygulama açıldığında Personel/Admin veya Hasta girişini seçme ekranı."""

    def __init__(self, master):
        self.master = master
        master.title("Eczane Otomasyon Sistemi | Giriş Seçimi")
        master.geometry("500x350")

        # Pencereyi ortalama
        app_width = 500
        app_height = 350
        screen_width = master.winfo_screenwidth()
        screen_height = master.winfo_screenheight()
        x = (screen_width / 2) - (app_width / 2)
        y = (screen_height / 2) - (app_height / 2)
        master.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')
        master.resizable(False, False)

        main_frame = Frame(master, bg="#ecf0f1", padx=30, pady=30)
        main_frame.grid(row=0, column=0, sticky="nsew")
        master.grid_columnconfigure(0, weight=1)
        master.grid_rowconfigure(0, weight=1)

        Label(main_frame, text="HOŞ GELDİNİZ", font=("Arial", 18, "bold"), bg="#ecf0f1", fg="#2c3e50").grid(row=0,
                                                                                                            column=0,
                                                                                                            columnspan=2,
                                                                                                            pady=(0,
                                                                                                                  20))
        Label(main_frame, text="Giriş Türünü Seçiniz", font=("Arial", 14), bg="#ecf0f1", fg="#3498db").grid(row=1,
                                                                                                            column=0,
                                                                                                            columnspan=2,
                                                                                                            pady=(0,
                                                                                                                  40))

        # Personel/Admin Giriş Butonu
        Button(main_frame, text="PERSONEL / ADMİN GİRİŞİ",
               command=lambda: self.open_login(master, LoginScreen),
               bg="#2ecc71", fg="white", font=("Arial", 12, "bold"),
               relief=FLAT, bd=0, padx=20, pady=10).grid(row=2, column=0, padx=10, sticky="ew")

        # Hasta Giriş Butonu
        Button(main_frame, text="HASTA GİRİŞİ",
               command=lambda: self.open_login(master, PatientLoginScreen),
               bg="#e74c3c", fg="white", font=("Arial", 12, "bold"),
               relief=FLAT, bd=0, padx=20, pady=10).grid(row=2, column=1, padx=10, sticky="ew")

    def open_login(self, master, login_class):
        """Mevcut pencereyi kapatır ve seçilen giriş ekranını açar."""

        # Döngüyü kırmak için start_app'i yerel olarak içeri aktarır
        try:
            from main import start_app
        except ImportError:
            messagebox.showerror("Hata", "Uygulama başlatma modülü bulunamadı!")
            return

        master.destroy()
        root_login = Tk()
        login_class(root_login)
        root_login.mainloop()