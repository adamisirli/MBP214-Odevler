from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from db_manager import DatabaseManager


class PatientDashboardUI:
    """Hastanın kendi reçetelerini görüntülediği panel."""

    def __init__(self, master, patient_data, logout_command):
        self.master = master
        self.patient_data = patient_data
        self.logout_command = logout_command
        self.db = DatabaseManager()

        master.title(f"Eczane Otomasyon Sistemi | {patient_data['ad_soyad']} (Hasta Paneli)")
        master.geometry("1000x700")  # Ekranı genişletelim

        master.grid_rowconfigure(0, weight=1)
        master.grid_columnconfigure(0, weight=1)

        # Ana Frame
        self.main_frame = Frame(master, bg="#ecf0f1", padx=20, pady=20)
        self.main_frame.grid(row=0, column=0, sticky="nsew")
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(2, weight=1)  # Reçete içeriği için yer açtık

        self.create_header()
        self.create_prescription_list()
        self.create_detail_area()  # Yeni detay alanı

    def create_header(self):
        # Üst Bilgi Çubuğu
        header_frame = Frame(self.main_frame, bg="#ffffff", bd=1, relief=RAISED)
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        header_frame.grid_columnconfigure(0, weight=1)

        Label(header_frame,
              text=f"Hoş Geldiniz, Sn. {self.patient_data['ad_soyad']} (TC: {self.patient_data['tc_no']})",
              font=("Arial", 14, "bold"), bg="#ffffff", fg="#2c3e50", padx=10).grid(row=0, column=0, sticky="w",
                                                                                    pady=10)

        # Çıkış Butonu
        Button(header_frame, text="Çıkış Yap", command=self.handle_logout,
               bg="#e74c3c", fg="white", font=("Arial", 10, "bold"),
               relief=FLAT, padx=10).grid(row=0, column=1, sticky="e", padx=10)

    def handle_logout(self):
        self.master.destroy()
        self.logout_command()

    def create_prescription_list(self):
        Label(self.main_frame, text="ADINIZA YAZILMIŞ REÇETELER (Detay Görmek İçin Tıklayın)",
              font=("Arial", 16), fg="#e74c3c", bg="#ecf0f1").grid(row=1, column=0, sticky="nw", pady=(10, 5))

        # Liste Frame (Üst Kısım)
        list_frame = Frame(self.main_frame, bg="white")
        list_frame.grid(row=2, column=0, sticky="nsew", pady=10)
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        # Reçete Treeview
        scrollbar = Scrollbar(list_frame, orient=VERTICAL)

        self.patient_prescription_list = ttk.Treeview(list_frame, columns=("ID", "R. No", "Tarih", "Durum"),
                                                      show="headings", yscrollcommand=scrollbar.set)

        scrollbar.config(command=self.patient_prescription_list.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')

        self.patient_prescription_list.grid(row=0, column=0, sticky="nsew")

        self.patient_prescription_list.heading("ID", text="ID", anchor=W)
        self.patient_prescription_list.heading("R. No", text="Reçete No", anchor=W)
        self.patient_prescription_list.heading("Tarih", text="Veriliş Tarihi", anchor=W)
        self.patient_prescription_list.heading("Durum", text="Durum", anchor=W)

        self.patient_prescription_list.column("ID", width=30, anchor=CENTER)
        self.patient_prescription_list.column("R. No", width=150, anchor=CENTER)
        self.patient_prescription_list.column("Tarih", width=150, anchor=CENTER)
        self.patient_prescription_list.column("Durum", width=100, anchor=CENTER)

        self.patient_prescription_list.bind("<<TreeviewSelect>>", self.show_prescription_details)

        self.load_patient_prescriptions()

    def create_detail_area(self):
        # Detay Alanı Frame (Alt Kısım)
        self.detail_frame = Frame(self.main_frame, bg="#ecf0f1")
        self.detail_frame.grid(row=3, column=0, sticky="nsew", pady=(10, 0))
        self.detail_frame.grid_columnconfigure(0, weight=1)
        self.detail_frame.grid_rowconfigure(1, weight=1)

        Label(self.detail_frame, text="SEÇİLİ REÇETE İÇERİĞİ",
              font=("Arial", 14, "bold"), fg="#3498db", bg="#ecf0f1").grid(row=0, column=0, sticky="w", pady=(10, 5))

        detail_list_frame = Frame(self.detail_frame, bg="white")
        detail_list_frame.grid(row=1, column=0, sticky="nsew")
        detail_list_frame.grid_columnconfigure(0, weight=1)
        detail_list_frame.grid_rowconfigure(0, weight=1)

        # Detay Treeview
        detail_scrollbar = Scrollbar(detail_list_frame, orient=VERTICAL)
        self.detail_list = ttk.Treeview(detail_list_frame, columns=("İlaç Adı", "Miktar"),
                                        show="headings", yscrollcommand=detail_scrollbar.set)

        detail_scrollbar.config(command=self.detail_list.yview)
        detail_scrollbar.grid(row=0, column=1, sticky='ns')
        self.detail_list.grid(row=0, column=0, sticky="nsew")

        self.detail_list.heading("İlaç Adı", text="İlaç Adı", anchor=W)
        self.detail_list.heading("Miktar", text="Miktar", anchor=W)

        self.detail_list.column("İlaç Adı", width=300)
        self.detail_list.column("Miktar", width=100, anchor=CENTER)

    # --- MANTIK METOTLARI ---

    def load_patient_prescriptions(self):
        """Hastanın T.C. Kimlik Numarasına ait reçeteleri listeler."""
        for item in self.patient_prescription_list.get_children():
            self.patient_prescription_list.delete(item)

        # TC'yi kullanarak DB'den reçeteleri çek
        prescriptions = self.db.get_prescriptions_by_patient_tc(self.patient_data['tc_no'])

        for rec in prescriptions:
            self.patient_prescription_list.insert('', END, values=rec)

    def show_prescription_details(self, event):
        """Seçilen reçetenin içeriğini (İlaç ve Miktar) alt panele yükler."""
        selected_item = self.patient_prescription_list.selection()
        if not selected_item:
            return

        values = self.patient_prescription_list.item(selected_item, 'values')
        recete_id = values[0]  # Reçete ID'si (ilk sütun)

        # Önceki detayları temizle
        for item in self.detail_list.get_children():
            self.detail_list.delete(item)

        # Reçete içeriğini DB'den çek
        details = self.db.get_prescription_details(recete_id)

        if details:
            for ad, miktar in details:
                self.detail_list.insert('', END, values=(ad, miktar))
        else:
            self.detail_list.insert('', END, values=("Bu reçetede kayıtlı ilaç bulunamadı.", ""))